#!/usr/bin/env python3
"""
Personal Firewall using Python
Educational project based on Scapy.

Features:
- Sniffs IP packets and displays live traffic.
- Applies user-defined allow/block rules for IPs, ports and protocols.
- Logs suspicious/blocked packets to CSV.
- Optional iptables command generation for Linux.
- Safe default: monitoring/rule simulation does not modify the OS firewall.
"""

import argparse
import csv
import datetime as dt
import os
from dataclasses import dataclass
from typing import Optional

try:
    from scapy.all import sniff, IP, TCP, UDP, ICMP
except ImportError:
    sniff = None
    IP = TCP = UDP = ICMP = None

LOG_FILE = "firewall_log.csv"

@dataclass
class Rule:
    action: str                  # ALLOW or BLOCK
    protocol: str = "ANY"
    ip: str = "ANY"
    port: str = "ANY"

def load_rules(path: str):
    rules = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            rules.append(Rule(
                action=row["action"].strip().upper(),
                protocol=row.get("protocol", "ANY").strip().upper(),
                ip=row.get("ip", "ANY").strip(),
                port=row.get("port", "ANY").strip(),
            ))
    return rules

def init_log():
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["timestamp", "src_ip", "dst_ip", "protocol",
                        "src_port", "dst_port", "length", "action", "rule"])

def packet_info(pkt):
    if IP not in pkt:
        return None
    src = pkt[IP].src
    dst = pkt[IP].dst
    proto = "OTHER"
    sport = dport = "-"
    if TCP in pkt:
        proto = "TCP"
        sport, dport = pkt[TCP].sport, pkt[TCP].dport
    elif UDP in pkt:
        proto = "UDP"
        sport, dport = pkt[UDP].sport, pkt[UDP].dport
    elif ICMP in pkt:
        proto = "ICMP"
    return src, dst, proto, str(sport), str(dport), len(pkt)

def matches(rule: Rule, info):
    src, dst, proto, sport, dport, _ = info
    proto_ok = rule.protocol == "ANY" or rule.protocol == proto
    ip_ok = rule.ip == "ANY" or rule.ip in (src, dst)
    port_ok = rule.port == "ANY" or rule.port in (sport, dport)
    return proto_ok and ip_ok and port_ok

def decide(info, rules):
    # First matching rule wins. Default is ALLOW.
    for i, rule in enumerate(rules, 1):
        if matches(rule, info):
            return rule.action, i
    return "ALLOW", 0

def log_packet(info, action, rule_no):
    src, dst, proto, sport, dport, length = info
    with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow([
            dt.datetime.now().isoformat(timespec="seconds"),
            src, dst, proto, sport, dport, length, action, rule_no
        ])

def process_packet(pkt, rules):
    info = packet_info(pkt)
    if not info:
        return
    action, rule_no = decide(info, rules)
    log_packet(info, action, rule_no)
    src, dst, proto, sport, dport, length = info
    marker = "[BLOCK]" if action == "BLOCK" else "[ALLOW]"
    print(f"{marker} {src}:{sport} -> {dst}:{dport} {proto} len={length} rule={rule_no}")

def build_iptables_commands(rules):
    """Generate commands for review only; does not execute them."""
    commands = []
    for r in rules:
        if r.action != "BLOCK":
            continue
        parts = ["sudo", "iptables", "-A", "INPUT"]
        if r.protocol != "ANY":
            parts += ["-p", r.protocol.lower()]
        if r.ip != "ANY":
            parts += ["-s", r.ip]
        if r.port != "ANY" and r.protocol in ("TCP", "UDP"):
            parts += ["--dport", r.port]
        parts += ["-j", "DROP"]
        commands.append(" ".join(parts))
    return commands

def main():
    parser = argparse.ArgumentParser(description="Educational Python personal firewall")
    parser.add_argument("--rules", default="rules.csv")
    parser.add_argument("--iface", default=None, help="Network interface, e.g. eth0")
    parser.add_argument("--count", type=int, default=0, help="0 = continuous capture")
    parser.add_argument("--show-iptables", action="store_true",
                        help="Print equivalent Linux iptables commands without executing")
    args = parser.parse_args()

    rules = load_rules(args.rules)
    init_log()

    print("=== Personal Firewall (Educational Monitor) ===")
    print(f"Rules loaded: {len(rules)}")
    print(f"Log file: {LOG_FILE}")

    if args.show_iptables:
        print("\niptables commands for review (NOT executed):")
        for cmd in build_iptables_commands(rules):
            print(cmd)

    if sniff is None:
        print("\nScapy is not installed. Install it with: pip install scapy")
        return

    print("\nStarting packet monitor. Stop with Ctrl+C.")
    sniff(iface=args.iface, prn=lambda p: process_packet(p, rules),
          store=False, count=args.count)

if __name__ == "__main__":
    main()
