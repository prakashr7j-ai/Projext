# Personal Firewall using Python

## 1. Project objective
A lightweight educational personal firewall/traffic monitor that uses Scapy to inspect packets, apply configurable allow/block rules, and maintain an audit log.

## 2. Requirements
- Python 3.9+
- Linux/macOS/Windows for packet monitoring (administrator/root privileges may be required)
- Scapy

Install:
```bash
pip install scapy
```

## 3. Files
- `firewall.py` – main application
- `rules.csv` – editable rule set
- `firewall_log.csv` – generated packet audit log
- `requirements.txt` – dependency list

## 4. Run
Linux/macOS:
```bash
sudo python3 firewall.py
```

Choose an interface:
```bash
sudo python3 firewall.py --iface eth0
```

Capture a fixed number of packets:
```bash
sudo python3 firewall.py --count 50
```

Review equivalent iptables rules without changing the system:
```bash
python3 firewall.py --show-iptables
```

## 5. Rule format
CSV columns:
`action,protocol,ip,port`

Examples:
- `BLOCK,TCP,10.10.10.10,ANY`
- `BLOCK,TCP,ANY,23`
- `BLOCK,UDP,ANY,1900`
- `ALLOW,ANY,ANY,ANY`

Rules are evaluated from top to bottom; the first matching rule wins. The default is ALLOW.

## 6. Output
Every observed IP packet is written to `firewall_log.csv` with timestamp, source/destination IP, protocol, ports, length, action and matching rule.

## 7. Important project limitation
Scapy packet inspection and rule evaluation are implemented in user space. A BLOCK decision in this educational version is logged and displayed; it does not silently alter the operating system firewall. The `--show-iptables` option only prints possible Linux commands for review. If actual enforcement is required in a controlled Linux lab, the generated rules should be reviewed and applied manually by an administrator.

## 8. Suggested demonstration
1. Start the monitor.
2. Generate normal traffic by opening a website.
3. Change a rule to block a test IP/port in an isolated lab.
4. Generate matching traffic.
5. Show `[BLOCK]` entries and the CSV audit log.
6. Run `--show-iptables` and explain how OS-level enforcement could be integrated.

## 9. Ethical use
Use only on a computer/network you own or are explicitly authorized to monitor. Do not use packet capture to intercept other people's private traffic.
